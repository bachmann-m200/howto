/**
 ********************************************************************************
 * @file     template_app.hpp
 * @author   gravers
 * @version  $Revision: 000 $
 * @date     $LastChangeDate: Feb 18, 2013 1:20:23 PM $
 *
 * @brief    This is an example of an instance of a working task for
 *           an application.
 *
 ********************************************************************************
 * COPYRIGHT BY BACHMANN ELECTRONIC GmbH 2015
 *******************************************************************************/

/** Avoid problems with multiple inclusion */
#ifndef DEMO_APP_HPP_
#define DEMO_APP_HPP_


/** Includes */
#include <string>
#include "BETask.hpp"

/* SVI Client includes */
#include "Uint32Value.hpp"

/* SVI Server includes */
#include "SviExportHelper.hpp"

/* MIO includes */
#include "DIO232.hpp"
#include "AIO2XX.hpp"

/**
 * @addtogroup APP-TASK
 * @{
 */
class demo_app: public BETask


{
public:
    demo_app(BETaskConfiguration conf);
    ~demo_app();

    /**
     ********************************************************************************
     * @brief     This method is called cyclic for this application task.
     *******************************************************************************/
    void cycleWork(void);

    void cycleStart(void);

    void cycleEnd(void);

    void initSviClient();

    void initSviServer();

    void initMio();


private:

    /* SVI Client variables */
    AbstractSviGroup *pSviGroup;
    GenericSviItem<UINT32> *pTime_us;

    /* SVI Server variables */
    UINT32 uInt32Counter;

    /* MIO variables */
    BOOL chan1_in;
    BOOL chan2_in;
    BOOL chan3_out;

    DIO232* card6;
    AIO2XX* card7;

};

/** @} */

#endif  /** DEMO_APP_HPP_ */
