/**
 ********************************************************************************
 * @file     template_app.cpp
 * @author   gravers
 * @version  $Revision: 000 $
 * @date     $LastChangeDate: Feb 18, 2013 1:20:23 PM $
 *
 * @brief    This is an example of an instance of a working task for
 *           an application.
 *
 ********************************************************************************
 * COPYRIGHT BY BACHMANN ELECTRONIC GmbH 2015
 *******************************************************************************/
#define CLASS_NAME "demo_app"

/** Includes */
#include "mcpp.hpp"
#include "demo_app.hpp"
#include "BEModule.hpp"
#include "log_e.h"
#include <iostream>
#include "BETaskConfiguration.hpp"

using namespace std;

demo_app::demo_app(BETaskConfiguration conf) :
        BETask(conf)
{
    /* Init SVI Server variables */
    uInt32Counter = 0;

    /* Init MIO */
    chan1_in = false;
    chan2_in = false;
    chan3_out = false;

    /* Init functions */
    initSviClient();
    initSviServer();
    initMio();
}

demo_app::~demo_app()
{

}

void demo_app::cycleStart(void)
{
    /* Get MIO inputs */
    chan1_in = card6->getDigitalChannel(1)->getValue();
    chan2_in = card6->getDigitalChannel(2)->getValue();
}

void demo_app::cycleWork(void)
{
    /* MIO input */
    cycleStart();

    /* SVI Client variables */
    UINT32 time = pTime_us->getVal();
    log_Info("Time is: %u", time);

    /* SVI Server variables */
    uInt32Counter++;
    log_Info("Counter is: %u", uInt32Counter);

    /* MIO */
    chan3_out = (chan1_in && chan2_in);

    /* MIO output */
    cycleEnd();
}

void demo_app::cycleEnd(void)
{
    /* Set MIO outputs */
    card6->getDigitalChannel(3)->setValue(chan3_out);
    card7->getAnalogChannel(1)->setValue(uInt32Counter);
}

void demo_app::initSviClient()
{
    /* Create a SVI group and add a value to the group */
    pSviGroup = new SviGroup("MyGroup", this);
    pTime_us = pSviGroup->addValueItem<UINT32>("RES", "Time/Time_us");

    /* Set group active which causes a refresh of data for all items and add SVI client group to the task */
    pSviGroup->setActive(true);
    this->addSviGroup(this->pSviGroup);
}

void demo_app::initSviServer()
{
    /** Creates a helper class for creating descriptors */
    SviExportHelper helper;

    /** Export variables to SVI */
    this->exportToSvi(helper.exportValue("Counter", SVI_F_UINT32, true, true, (UINT32*) &uInt32Counter));
    this->exportToSvi(helper.exportValue("MIO/chan1_in", SVI_F_UINT1, true, false, (UINT32*) &chan1_in));
    this->exportToSvi(helper.exportValue("MIO/chan2_in", SVI_F_UINT1, true, false, (UINT32*) &chan2_in));
    this->exportToSvi(helper.exportValue("MIO/chan3_out", SVI_F_UINT1, true, false, (UINT32*) &chan3_out));
}

void demo_app::initMio()
{
    /* Get the IO configuration for the task */
    MIOConfiguration *pIOConf = getIOConfiguration();

    /* Add a card to the IO configuration */
    pIOConf->addCard(new DIO232(6));
    card6 = (DIO232*) pIOConf->getCard(6);

    /* Add a card to the IO configuration */
    pIOConf->addCard(new AIO2XX(7));
    card7 = (AIO2XX*) pIOConf->getCard(7);
}
