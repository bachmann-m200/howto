/**
 ********************************************************************************
 * @file     template_app.hpp
 * @author   gravers
 * @version  $Revision: 000 $
 * @date     $LastChangeDate: Feb 18, 2013 1:20:23 PM $
 *
 * @brief    This is an example of an instance of a working task for
 *           an application.
 *
 ********************************************************************************
 * COPYRIGHT BY BACHMANN ELECTRONIC GmbH 2015
 *******************************************************************************/

/** Avoid problems with multiple inclusion */
#ifndef EVENT_APP_HPP_
#define EVENT_APP_HPP_


/** Includes */
#include <string>
#include "BETask.hpp"
#include "VirtualSviHandler.hpp"
#include "svi/atomic/ValueWrapper.hpp"
#include "svi/atomic/ArrayWrapper.hpp"
#include "SviExportHelper.hpp"
#include "SviException.hpp"
#include "SviVirtualExportDescriptor.hpp"
#include <fstream>
#include "taskLib.h"
#include "tickLib.h"
#include "mio/cards/UFB/CAN.hpp"

#include "cyclic_app.hpp"

struct My_Struct{
    UINT32 val1;
    UINT32 val2;
    UINT32 val3;
};

/**
 * @addtogroup APP-TASK
 * @{
 */
class event_app: public BETask, public VirtualSviHandler


{
public:
    event_app(BETaskConfiguration conf, cyclic_app* cyclicTask);
    ~event_app();

    /**
     ********************************************************************************
     * @brief     This method is called cyclic for this application task.
     *******************************************************************************/
    void cycleWork(void);

    void initSviServer();
    void initMio();

    SINT32 handleRead(SviVirtualExportDescriptor *pDesc, UINT32 *pBuffer, UINT32 sessionID);
    SINT32 handleBlkRead(SviVirtualExportDescriptor *pDesc, VOID *pBuffer, UINT32 bufferLength,
            UINT32 sessionID);
    SINT32 handleWrite(SviVirtualExportDescriptor *pDesc, const VOID *pBuffer, UINT32 bufferLength,
            UINT32 sessionID);


private:

    cyclic_app* pCyclicTask;

    BOOL8 boolValExp;
    SINT32 sInt32Value;
    UINT64 uInt64Value;
    SINT32 sInt32Array[10];
    char aString[9];
    char stringArray[3][10];
    BOOL8 sviInitialized;
    UINT32 myNumberSequence[10];
    REAL64 real64Arr[5];
    ValueWrapper<UINT64> *pUint64Wrap;
    ArrayWrapper<REAL64> *pArrWrap;

    ArrayWrapper<UINT8> *pUint88Wrap;
    My_Struct structVal;


    void doEventDelay(void);
    void doTerminate(void);

    SEM_ID runSema;

    CAN* card4;

};

/** @} */

#endif  /** EVENT_APP_HPP_ */
