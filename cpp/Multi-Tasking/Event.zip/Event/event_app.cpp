/**
 ********************************************************************************
 * @file     template_app.cpp
 * @author   gravers
 * @version  $Revision: 000 $
 * @date     $LastChangeDate: Feb 18, 2013 1:20:23 PM $
 *
 * @brief    This is an example of an instance of a working task for
 *           an application.
 *
 ********************************************************************************
 * COPYRIGHT BY BACHMANN ELECTRONIC GmbH 2015
 *******************************************************************************/
#define CLASS_NAME "event_app"

/** Includes */
#include "mcpp.hpp"
#include "event_app.hpp"
#include "BEModule.hpp"
#include "log_e.h"
#include <iostream>
#include "BETaskConfiguration.hpp"

using namespace std;

event_app::event_app(BETaskConfiguration conf, cyclic_app* cyclicTask) :
        BETask(conf)
{
    runSema = semBCreate(SEM_Q_PRIORITY, SEM_EMPTY);
    pCyclicTask = cyclicTask;
    initSviServer();
    //initMio();
}

event_app::~event_app()
{
    SAFE_DELETE(pArrWrap);
    SAFE_DELETE(pUint64Wrap);
}

void event_app::cycleWork(void)
{

    log_Info("Event task, cycleWork called, counter value of cycle task: %u", pCyclicTask->getCounter());

    //card4->getValue(1);
    //card4->setValue(2, 3.0);
}

void event_app::initSviServer()
{
    /** Initialize the values to export */
    sviInitialized = false;
    sInt32Value = 100;
    uInt64Value = 123456789101112123ULL;

    for (int i = 0; i < 10; i++)
    {
        sInt32Array[i] = i;
    }

    sprintf(aString, "Bachmann");

    /** Values are assigned to array entries. sprintf adds the 0 termination which is needed. */
    sprintf(stringArray[0], "Exporting");
    sprintf(stringArray[1], "is       ");
    sprintf(stringArray[2], "funny    ");

    /** Initialize the number sequence for the virtual variable */
    for (int i = 1; i <= 10; i++)
    {
        myNumberSequence[i - 1] = i;
    }

    try
    {
        /** Creates a helper class for creating descriptors */
        SviExportHelper helper;

        /** Export an Integer value */
        this->exportToSvi(
                helper.exportValue("AnIntegerValue", SVI_F_SINT32, true, true,
                        (UINT32*) &sInt32Value));

        /** Export an Integer value */
        this->exportToSvi(
                helper.exportValue("AnUnsigned64BitValue", SVI_F_UINT64, true, true,
                        (UINT32*) &uInt64Value));

        /** Export an String value. Remember to add an extra byte for the 0 termination */
        this->exportToSvi(helper.exportString("AString", (UINT32*) &aString, 9));

        /** Export an SINT32 array, where individual items are exported too. */
        this->exportToSvi(
                helper.exportArray("AnIntegerArray", (UINT32*) &sInt32Array, SVI_F_SINT32, 40,
                        true));

        /** Export a String array with individual items.
         * Array size is 3 and strings has a length of 10 chars (including the 0 termination).
         */
        this->exportToSvi(
                helper.exportStringArray("AStringArray", (UINT32*) &stringArray, 3, 10, true, true,
                        true));

        /** Export virtual SVI value with a handler
         *
         *  PLEATE NOTE: When using the simplified function, it will be difficult to use the same
         *  handler for reading/writing of multiple items, since all of the will be assigned to
         *  id = 0. See example below for specifying id and optional parameter.
         *
         * @see the VirtualSviHandler interface for more information.
         * */

        this->exportToSvi(
                helper.exportVirtualValue("AVirtualValue", SVI_F_REAL32, true, true, this));

        /**Export virtual SVI array
         * This should show the general purpose with virtual variables. We export an array, which
         * the client can read and modify.
         *
         * The handleRead(..) / handleBlkRead(..) and handleWrite(..) specifies what to do when
         * this happens and is called accordingly.
         *
         * PLEASE NOTE: The reference &sInt32Value is NOT an exported value. It is a parameter, which
         * is automatically passed to the read/write functions.
         *
         * @see the VirtualSviHandler interface for more information.
         *
         * This example will show an array containing a number sequence. User is allowed to change
         * an entry in the array, but the complete number sequence will change related to this number.
         */
        this->exportToSvi(
                helper.exportVirtualArray("AVirtualArrayNumberSequence", SVI_F_UINT32, 40, true,
                        true, this, 2, (VOID*) &sInt32Value));

        /**
         *  M1 Multicore capabilities can introduce race conditions, which can corrupt >32 bit datatypes exported to SVI.
         *  Use special functionality to handle these race conditions
         */
        this->pUint64Wrap = helper.exportAtomicValue<UINT64>("AtomicUint64", true, true, this);

        this->pArrWrap = helper.exportAtomicArray<REAL64>("AtomicReal64Arr", 10 * sizeof(REAL64), true, true, true, this);

        this->pUint88Wrap = helper.exportAtomicArray<UINT8>("MyStruct", sizeof(structVal), true, true, false, this);
        memset(&structVal, 0, sizeof(structVal));
        this->pUint88Wrap->setEntries((UINT8*)&structVal, sizeof(structVal));

        REAL64 arr[10];
        for (int i = 0; i < 10; i++)
        {
            arr[i] = i;
        }
        this->pArrWrap->setEntries(arr, 10);

        sviInitialized = true;
    }
    catch(SviException &sviException)
    {
        log_Err("SVI export did not succeed. Cause: %s", sviException.what());
    }
    catch(...)
    {
        log_Err("Unknown exception when exporting SVI. Check logbook or console");
    }
}

SINT32 event_app::handleRead(SviVirtualExportDescriptor *pDesc, UINT32 *pBuffer,
        UINT32 sessionID)
{

    SYS_CPUUSAGE cu;

    /**
     * In current versions of MSys (>= V2.00), the check for enabled
     * coprocessor will be done by the SVI handler.
     */
    if (!sys_CheckFpuOption())
        return (ERROR);

    /** Get CPU usage informations */
    if (sys_GetCpuUsage(&cu) < 0)
        *((REAL32*) pBuffer) = 0.0;
    else
        *((REAL32*) pBuffer) = ((REAL32) cu.CpuUsageTotal / (REAL32) cu.TotalTime) * 100.0;

    return (SVI_E_OK);
}

SINT32 event_app::handleWrite(SviVirtualExportDescriptor *pDesc, const VOID *pBuffer,
        UINT32 bufferLength, UINT32 sessionID)
{
    log_Info("Event task, handleWrite called, counter value of cycle task: %u", pCyclicTask->getCounter());

    if (pDesc->getId() == 2) /** Use ID in case this function handles more than one virtual variable. */
    {

        /** Find the index, where the user changed the value */
        UINT32 newValue = 0;
        UINT32 index = 0;
        BOOL8 valueChangeFound = false;
        UINT32* pValues = (UINT32*) pBuffer;
        for (int i = 0; i < 10; i++)
        {
            if ((*pValues) != myNumberSequence[i])
            {
                newValue = (*pValues);
                index = i;
                valueChangeFound = true;
                break;
            }
            pValues++;
        }

        /** If a change happened, then modify the number sequence to match the changed value. */
        if (valueChangeFound)
        {
            /** Since we are operating on unsigned datatype, lowest sequence is 1..10 */
            UINT32 startValue = 0;
            if (newValue > index)
            {
                startValue = newValue - index;
            }

            for (int i = 0; i < 10; i++)
            {
                myNumberSequence[i] = (startValue + i);
            }
        }
    }
    else
    {
        REAL32 value = *((REAL32*) pBuffer);
        log_Info("Handle write for %s! Value is: %f ", pDesc->getVarName().c_str(), value);
        log_Info("The id is: %d ", pDesc->getId());
    }
    return SVI_E_OK;
}

SINT32 event_app::handleBlkRead(SviVirtualExportDescriptor *pDesc, VOID *pBuffer,
        UINT32 bufferLength, UINT32 sessionID)
{
    if (pDesc->getId() == 2) /** Use ID in case this function handles more than one virtual variable. */
    {
        memcpy(pBuffer, (VOID*) &myNumberSequence, 40);
    }

    return SVI_E_OK;
}

void event_app::doEventDelay(void)
{
    //Here you can do anything you want. Wait for interrupt, IO, network or just a method call from other thread.

    //Example here is just sleeping a bit :)
    taskDelay(10000);

}

void event_app::doTerminate(void){
    //If you have locks, or waiting for network, you need to delete them now
   //SW module is terminating
}

void event_app::initMio()
{
    /* Get the IO configuration for the task */
    MIOConfiguration *pIOConf = getIOConfiguration();

    /* Add a card to the IO configuration */
    pIOConf->addCard(new CAN(4));
    card4 = (CAN*) pIOConf->getCard(4);
}

