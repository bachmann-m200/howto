/************************************************************
 * This file has been generated with munch.exe V2.03 Release *
 *                                                          *
 * Helper file that initializes static C++ constructs in    *
 * Bachmann modules.                                        *
 *                                                          *
 * It creates an array of constructors and destructors      *
 * so that the operating system can find and call them.     *
 *                                                          *
 * GNU C/C++ compiler should be used to compile this.       *
 * If a C++ compiler is used, -fdollars-in-identifiers flag *
 * should be added.                                         *
 *                                                          *
 ************************************************************
 * Copyright (c) 1998-2019 Bachmann Electronic GmbH         *
 ************************************************************
 */

void __GLOBAL__I_65535_0__Z13isMultipleof5j();
void __GLOBAL__I_65535_0__Z4lockP7SVI_VARP8Lockable();
void __GLOBAL__I_65535_0__ZN10IOStrategyC2Ev();
void __GLOBAL__I_65535_0__ZN11BETaskState17STATE_INITIALIZEDE();
void __GLOBAL__I_65535_0__ZN12MIOerrorcode13MIO_ER_OK_STRB5cxx11E();
void __GLOBAL__I_65535_0__ZN13BEModuleState10STATE_INITE();
void __GLOBAL__I_65535_0__ZN13BasicIoModule12TYPE_UNKNOWNE();
void __GLOBAL__I_65535_0__ZN13StdIOStrategyC2Ev();
void __GLOBAL__I_65535_0__ZN15SviExportHelper11exportValueENSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEjbbPj();
void __GLOBAL__I_65535_0__ZN16BasicMixedModuleC2Ev();
void __GLOBAL__I_65535_0__ZN18BasicDigitalModuleC2Ev();
void __GLOBAL__I_65535_0__ZN19ModuleConfigurationC2ENSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE();
void __GLOBAL__I_65535_0__ZN26SviVirtualExportDescriptorC2ENSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEjbbP17VirtualSviHandler();
void __GLOBAL__I_65535_0__ZN7Version16m_VersionTypeMapB5cxx11E();
void __GLOBAL__I_65535_0__ZN8BEModuleC2Ev();
void __GLOBAL__I_65535_0__ZN8EOIState5doEOIEP8BEModule();
void __GLOBAL__I_65535_0__ZN9event_appC2E19BETaskConfigurationP10cyclic_app();
void __GLOBAL__I_65535_0__ZNSt10ctype_base5spaceE();
void __GLOBAL__I_65535_0__ZNSt12ctype_bynameIcEC2ERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEj();
void __GLOBAL__I_65535_0__ZNSt12ctype_bynameIcEC2ERKSsj();
void __GLOBAL__I_65535_0__ZNSt3_V214error_categoryD2Ev();
void __GLOBAL__I_65535_0__ZNSt7codecvtIDsc9mbstate_tE2idE();
void __GLOBAL__I_65535_0__ZNSt7codecvtIcc9mbstate_tE2idE();
void __GLOBAL__I_65535_0___cxa_allocate_exception();
void __GLOBAL__I_65535_0___cxa_get_globals_fast();
void __GLOBAL__I_65535_0_callBack_M1Scan();

extern void (*_ctors[])();
void (*_ctors[])() = {
	__GLOBAL__I_65535_0__Z13isMultipleof5j,
	__GLOBAL__I_65535_0__Z4lockP7SVI_VARP8Lockable,
	__GLOBAL__I_65535_0__ZN10IOStrategyC2Ev,
	__GLOBAL__I_65535_0__ZN11BETaskState17STATE_INITIALIZEDE,
	__GLOBAL__I_65535_0__ZN12MIOerrorcode13MIO_ER_OK_STRB5cxx11E,
	__GLOBAL__I_65535_0__ZN13BEModuleState10STATE_INITE,
	__GLOBAL__I_65535_0__ZN13BasicIoModule12TYPE_UNKNOWNE,
	__GLOBAL__I_65535_0__ZN13StdIOStrategyC2Ev,
	__GLOBAL__I_65535_0__ZN15SviExportHelper11exportValueENSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEjbbPj,
	__GLOBAL__I_65535_0__ZN16BasicMixedModuleC2Ev,
	__GLOBAL__I_65535_0__ZN18BasicDigitalModuleC2Ev,
	__GLOBAL__I_65535_0__ZN19ModuleConfigurationC2ENSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE,
	__GLOBAL__I_65535_0__ZN26SviVirtualExportDescriptorC2ENSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEjbbP17VirtualSviHandler,
	__GLOBAL__I_65535_0__ZN7Version16m_VersionTypeMapB5cxx11E,
	__GLOBAL__I_65535_0__ZN8BEModuleC2Ev,
	__GLOBAL__I_65535_0__ZN8EOIState5doEOIEP8BEModule,
	__GLOBAL__I_65535_0__ZN9event_appC2E19BETaskConfigurationP10cyclic_app,
	__GLOBAL__I_65535_0__ZNSt10ctype_base5spaceE,
	__GLOBAL__I_65535_0__ZNSt12ctype_bynameIcEC2ERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEj,
	__GLOBAL__I_65535_0__ZNSt12ctype_bynameIcEC2ERKSsj,
	__GLOBAL__I_65535_0__ZNSt3_V214error_categoryD2Ev,
	__GLOBAL__I_65535_0__ZNSt7codecvtIDsc9mbstate_tE2idE,
	__GLOBAL__I_65535_0__ZNSt7codecvtIcc9mbstate_tE2idE,
	__GLOBAL__I_65535_0___cxa_allocate_exception,
	__GLOBAL__I_65535_0___cxa_get_globals_fast,
	__GLOBAL__I_65535_0_callBack_M1Scan,
	0
};

void __GLOBAL__D_65535_1__Z13isMultipleof5j();
void __GLOBAL__D_65535_1__Z4lockP7SVI_VARP8Lockable();
void __GLOBAL__D_65535_1__ZN10IOStrategyC2Ev();
void __GLOBAL__D_65535_1__ZN12MIOerrorcode13MIO_ER_OK_STRB5cxx11E();
void __GLOBAL__D_65535_1__ZN13BEModuleState10STATE_INITE();
void __GLOBAL__D_65535_1__ZN13BasicIoModule12TYPE_UNKNOWNE();
void __GLOBAL__D_65535_1__ZN13StdIOStrategyC2Ev();
void __GLOBAL__D_65535_1__ZN15SviExportHelper11exportValueENSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEjbbPj();
void __GLOBAL__D_65535_1__ZN16BasicMixedModuleC2Ev();
void __GLOBAL__D_65535_1__ZN18BasicDigitalModuleC2Ev();
void __GLOBAL__D_65535_1__ZN19ModuleConfigurationC2ENSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE();
void __GLOBAL__D_65535_1__ZN26SviVirtualExportDescriptorC2ENSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEjbbP17VirtualSviHandler();
void __GLOBAL__D_65535_1__ZN7Version16m_VersionTypeMapB5cxx11E();
void __GLOBAL__D_65535_1__ZN8BEModuleC2Ev();
void __GLOBAL__D_65535_1__ZN8EOIState5doEOIEP8BEModule();
void __GLOBAL__D_65535_1__ZN9event_appC2E19BETaskConfigurationP10cyclic_app();
void __GLOBAL__D_65535_1__ZNSt3_V214error_categoryD2Ev();
void __GLOBAL__D_65535_1___cxa_get_globals_fast();
void __GLOBAL__D_65535_1_callBack_M1Scan();

extern void (*_dtors[])();
void (*_dtors[])() = {
	__GLOBAL__D_65535_1__Z13isMultipleof5j,
	__GLOBAL__D_65535_1__Z4lockP7SVI_VARP8Lockable,
	__GLOBAL__D_65535_1__ZN10IOStrategyC2Ev,
	__GLOBAL__D_65535_1__ZN12MIOerrorcode13MIO_ER_OK_STRB5cxx11E,
	__GLOBAL__D_65535_1__ZN13BEModuleState10STATE_INITE,
	__GLOBAL__D_65535_1__ZN13BasicIoModule12TYPE_UNKNOWNE,
	__GLOBAL__D_65535_1__ZN13StdIOStrategyC2Ev,
	__GLOBAL__D_65535_1__ZN15SviExportHelper11exportValueENSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEjbbPj,
	__GLOBAL__D_65535_1__ZN16BasicMixedModuleC2Ev,
	__GLOBAL__D_65535_1__ZN18BasicDigitalModuleC2Ev,
	__GLOBAL__D_65535_1__ZN19ModuleConfigurationC2ENSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE,
	__GLOBAL__D_65535_1__ZN26SviVirtualExportDescriptorC2ENSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEjbbP17VirtualSviHandler,
	__GLOBAL__D_65535_1__ZN7Version16m_VersionTypeMapB5cxx11E,
	__GLOBAL__D_65535_1__ZN8BEModuleC2Ev,
	__GLOBAL__D_65535_1__ZN8EOIState5doEOIEP8BEModule,
	__GLOBAL__D_65535_1__ZN9event_appC2E19BETaskConfigurationP10cyclic_app,
	__GLOBAL__D_65535_1__ZNSt3_V214error_categoryD2Ev,
	__GLOBAL__D_65535_1___cxa_get_globals_fast,
	__GLOBAL__D_65535_1_callBack_M1Scan,
	0
};


__asm(".section \".wrs_build_vars\",\"a\"");
__asm("	.ascii \"tag SMP 0\"");
__asm("	.byte 0");
__asm("	.ascii \"end\"");
__asm("	.byte 0");
__asm(".previous");
