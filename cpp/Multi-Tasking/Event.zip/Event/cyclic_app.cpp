/**
 ********************************************************************************
 * @file     template_app.cpp
 * @author   gravers
 * @version  $Revision: 000 $
 * @date     $LastChangeDate: Feb 18, 2013 1:20:23 PM $
 *
 * @brief    This is an example of an instance of a working task for
 *           an application.
 *
 ********************************************************************************
 * COPYRIGHT BY BACHMANN ELECTRONIC GmbH 2015
 *******************************************************************************/
#define CLASS_NAME "cyclic_app"

/** Includes */
#include "mcpp.hpp"
#include "cyclic_app.hpp"
#include "BEModule.hpp"
#include "log_e.h"
#include <iostream>
#include "BETaskConfiguration.hpp"

using namespace std;

bool isMultipleof5(UINT32 n)
{
    // If n is a multiple of 5 then we
    // make sure that last digit of n is 0
    if ( (n & 1) == 1 )
    {
        n <<= 1;
    }

    REAL32 x = n;
    x = ( (UINT32)(x * 0.1) ) * 10;

    // If last digit of n is 0 then n
    // will be equal to (int)x
    if((UINT32) x == n)
    {
        return true;
    }

    return false;
}

cyclic_app::cyclic_app(BETaskConfiguration conf) :
        BETask(conf)
{
    counter = 0;
}

cyclic_app::~cyclic_app()
{
}

void cyclic_app::cycleWork(void)
{
    counter++;
    log_Info("Cyclic task, counter: %u", counter);

    if(isMultipleof5(counter))
    {

    }
}

UINT32 cyclic_app::getCounter()
{
    return counter;
}
